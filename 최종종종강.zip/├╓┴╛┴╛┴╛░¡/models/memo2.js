var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var Memo2 = new Schema({
   content:  {type: String}
});

module.exports = mongoose.model('memo2', Memo2);
